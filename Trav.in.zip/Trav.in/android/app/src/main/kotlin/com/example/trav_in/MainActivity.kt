package com.example.trav_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
