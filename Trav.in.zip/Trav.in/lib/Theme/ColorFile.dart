import 'package:flutter/widgets.dart';

class AppColor {
  static Color TicketGrey = const Color(0xFF526799);
  static Color TicketBlue = const Color(0xFF0288D1);
}